#pragma once

namespace big
{
	bool hook_sgg_BacktraceHandleException(_EXCEPTION_POINTERS* exception);
} // namespace big

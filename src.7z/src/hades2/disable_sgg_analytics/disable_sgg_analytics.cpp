namespace big
{
	void hook_sgg_ForgeRenderer_PrintErrorMessageAndAssert()
	{
	}
} // namespace big

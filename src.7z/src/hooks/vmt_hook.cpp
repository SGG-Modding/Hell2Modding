#include "vmt_hook.hpp"



namespace big
{
	vmt_hook::vmt_hook() :
	    m_object(nullptr),
	    m_num_funcs(0),
	    m_original_table(nullptr),
	    m_new_table(nullptr)
	{
	}

	vmt_hook::vmt_hook(void* obj, std::size_t num_funcs)
	{
		init(obj, num_funcs);
	}

	void vmt_hook::init(void* obj, std::size_t num_funcs)
	{
		m_object         = static_cast<void***>(obj);
		m_num_funcs      = num_funcs;
		m_original_table = *m_object;
		m_new_table      = std::make_unique<void*[]>(m_num_funcs);

		std::copy_n(m_original_table, m_num_funcs, m_new_table.get());
	}

	vmt_hook::~vmt_hook()
	{
		disable();
	}

	void vmt_hook::hook(std::size_t index, void* func)
	{
		m_new_table[index] = func;
	}

	void vmt_hook::unhook(std::size_t index)
	{
		m_new_table[index] = m_original_table[index];
	}

	void vmt_hook::enable()
	{
		*m_object = m_new_table.get();
	}

	void vmt_hook::disable()
	{
		if (m_object)
		{
			*m_object = m_original_table;
		}
	}
} // namespace big

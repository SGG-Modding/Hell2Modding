#pragma once
#include "load_module_result.hpp"
#include "lua/bindings/gui_element.hpp"
#include "lua_patch.hpp"
#include "module_info.hpp"

#include <thunderstore/v1/manifest.hpp>

namespace big
{
	class lua_module
	{
		module_info m_info;

		sol::environment m_env;

	public:


		//lua_module_data m_data;

		lua_module(const module_info& module_info, sol::state_view& state);
	};
} // namespace big

#pragma once

#include "lua/bindings/gui_element.hpp"
#include "lua/lua_patch.hpp"

namespace big
{
	struct lua_module_data
	{
		std::vector<sol::protected_function> m_on_all_mods_loaded_callbacks;

		std::vector<sol::protected_function> m_pre_code_execute_callbacks;
		std::vector<sol::protected_function> m_post_code_execute_callbacks;

		std::unordered_map<void*, std::vector<sol::protected_function>> m_pre_builtin_execute_callbacks;
		std::unordered_map<void*, std::vector<sol::protected_function>> m_post_builtin_execute_callbacks;

		std::unordered_map<void*, std::vector<sol::protected_function>> m_pre_script_execute_callbacks;
		std::unordered_map<void*, std::vector<sol::protected_function>> m_post_script_execute_callbacks;

		std::vector<std::unique_ptr<lua::gui::gui_element>> m_menu_bar_callbacks;
		std::vector<std::unique_ptr<lua::gui::gui_element>> m_always_draw_independent_gui;
		std::vector<std::unique_ptr<lua::gui::gui_element>> m_independent_gui;

		std::vector<std::unique_ptr<lua_patch>> m_registered_patches;

		std::vector<void*> m_allocated_memory;
	};

	struct mod_context
	{
		std::string m_guid;

		lua_module_data m_data;

		sol::table m_log;

		static inline std::unordered_map<std::string, std::unique_ptr<mod_context>> guid_to_instance;

		mod_context(const std::string& guid) :
		    m_guid(guid)
		{
		}
	};

} // namespace big

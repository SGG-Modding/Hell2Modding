#pragma once
#include "log.hpp"

namespace lua::log
{
	static void log_internal(sol::variadic_args& args, sol::this_state state, al::eLogLevel level, const std::string& mod_guid = "")
	{
		std::stringstream data;

		size_t i                        = 0;
		const size_t last_element_index = args.size() - 1;
		for (const auto& arg : args)
		{
			data << sol::state_view(state)["_h2m_tostring"](arg).get<const char*>();

			if (i != last_element_index)
			{
				data << '\t';
			}

			i++;
		}

		LOG(level) << mod_guid << ": " << data.str();
	}

	// Lua API: Table
	// Name: log
	// Table containing functions for printing to console / log file.

	// Lua API: Function
	// Table: log
	// Name: info
	// Param: args: any
	// Logs an informational message.
	static void info(sol::variadic_args args, sol::this_state state)
	{
		log_internal(args, state, INFO);
	}

	// Lua API: Function
	// Table: log
	// Name: warning
	// Param: args: any
	// Logs a warning message.
	static void warning(sol::variadic_args args, sol::this_state state)
	{
		log_internal(args, state, WARNING);
	}

	// Lua API: Function
	// Table: log
	// Name: debug
	// Param: args: any
	// Logs a debug message.
	static void debug(sol::variadic_args args, sol::this_state state)
	{
		log_internal(args, state, VERBOSE);
	}

	// Lua API: Function
	// Table: log
	// Name: error
	// Param: args: any
	// Logs an error message.
	static sol::reference error(sol::variadic_args args, sol::this_state state)
	{
		log_internal(args, state, FATAL);

		return sol::state_view(state)["_h2m_error"](args);
	}

	void bind(sol::state_view& state, sol::usertype<big::mod_context>& lua_ext)
	{
		state["_h2m_tostring"] = state["tostring"];

		state["print"]      = info;
		state["_h2m_error"] = state["error"];
		state["error"]      = error;

		lua_ext["log"] = sol::property(
		    [](big::mod_context& env, sol::this_state st) -> sol::table&
		    {
			    if (!env.m_log.valid())
			    {
				    env.m_log = sol::table(st, sol::create);

				    env.m_log["info"] = [mod_guid = env.m_guid](sol::variadic_args args, sol::this_state state)
				    {
					    log_internal(args, state, INFO, mod_guid);
				    };

				    env.m_log["warning"] = [mod_guid = env.m_guid](sol::variadic_args args, sol::this_state state)
				    {
					    log_internal(args, state, WARNING, mod_guid);
				    };

				    env.m_log["debug"] = [mod_guid = env.m_guid](sol::variadic_args args, sol::this_state state)
				    {
					    log_internal(args, state, VERBOSE, mod_guid);
				    };

				    env.m_log["error"] = [mod_guid = env.m_guid](sol::variadic_args args, sol::this_state state)
				    {
					    log_internal(args, state, FATAL, mod_guid);

					    return sol::state_view(state)["_h2m_error"](args);
				    };
			    }

			    return env.m_log;
		    });
	}
} // namespace lua::log

#include "gui.hpp"

#include "gui/gui.hpp"
#include "gui_element.hpp"
#include "raw_imgui_callback.hpp"

namespace lua::gui
{
	static void add_menu_bar_callback(big::mod_context& env, std::unique_ptr<lua::gui::gui_element> element)
	{
		env.m_data.m_menu_bar_callbacks.push_back(std::move(element));
	}

	static void add_always_draw_independent_element(big::mod_context& env, std::unique_ptr<lua::gui::gui_element> element)
	{
		env.m_data.m_always_draw_independent_gui.push_back(std::move(element));
	}

	static void add_independent_element(big::mod_context& env, std::unique_ptr<lua::gui::gui_element> element)
	{
		env.m_data.m_independent_gui.push_back(std::move(element));
	}

	// Lua API: Function
	// Table: gui
	// Name: is_open
	// Returns: bool: Returns true if the GUI is open.
	static bool is_open(big::mod_context& env)
	{
		return big::g_gui->is_open();
	}

	// Lua API: Function
	// Table: gui
	// Name: add_to_menu_bar
	// Param: imgui_rendering: function: Function that will be called under your dedicated space in the imgui main menu bar.
	// Registers a function that will be called under your dedicated space in the imgui main menu bar.
	// **Example Usage:**
	// ```lua
	// gui.add_to_menu_bar(function()
	//   if ImGui.BeginMenu("Ayo") then
	//       if ImGui.Button("Label") then
	//         log.info("hi")
	//       end
	//       ImGui.EndMenu()
	//   end
	// end)
	// ```
	static lua::gui::raw_imgui_callback* add_to_menu_bar(big::mod_context& env, sol::protected_function imgui_rendering)
	{
		auto element = std::make_unique<lua::gui::raw_imgui_callback>(imgui_rendering);
		auto el_ptr  = element.get();
		add_menu_bar_callback(env, std::move(element));
		return el_ptr;
	}

	// Lua API: Function
	// Table: gui
	// Name: add_always_draw_imgui
	// Param: imgui_rendering: function: Function that will be called every rendering frame, regardless of the gui is in its open state. You can call ImGui functions in it, please check the ImGui.md documentation file for more info.
	// Registers a function that will be called every rendering frame, regardless of the gui is in its open state. You can call ImGui functions in it, please check the ImGui.md documentation file for more info.
	// **Example Usage:**
	// ```lua
	// gui.add_always_draw_imgui(function()
	//   if ImGui.Begin("My Custom Window") then
	//       if ImGui.Button("Label") then
	//         log.info("hi")
	//       end
	//
	//   end
	//   ImGui.End()
	// end)
	// ```
	static lua::gui::raw_imgui_callback* add_always_draw_imgui(big::mod_context& env, sol::protected_function imgui_rendering)
	{
		auto element = std::make_unique<lua::gui::raw_imgui_callback>(imgui_rendering);
		auto el_ptr  = element.get();
		add_always_draw_independent_element(env, std::move(element));
		return el_ptr;
	}

	// Lua API: Function
	// Table: gui
	// Name: add_imgui
	// Param: imgui_rendering: function: Function that will be called every rendering frame, only if the gui is in its open state. You can call ImGui functions in it, please check the ImGui.md documentation file for more info.
	// Registers a function that will be called every rendering frame, only if the gui is in its open state. You can call ImGui functions in it, please check the ImGui.md documentation file for more info.
	// **Example Usage:**
	// ```lua
	// gui.add_imgui(function()
	//   if ImGui.Begin("My Custom Window") then
	//       if ImGui.Button("Label") then
	//         log.info("hi")
	//       end
	//
	//   end
	//   ImGui.End()
	// end)
	// ```
	static lua::gui::raw_imgui_callback* add_imgui(big::mod_context& env, sol::protected_function imgui_rendering)
	{
		auto element = std::make_unique<lua::gui::raw_imgui_callback>(imgui_rendering);
		auto el_ptr  = element.get();
		add_independent_element(env, std::move(element));
		return el_ptr;
	}

	void bind(sol::usertype<big::mod_context>& state)
	{
		state["gui_is_open"]               = is_open;
		state["gui_add_imgui"]             = add_imgui;
		state["gui_add_always_draw_imgui"] = add_always_draw_imgui;
		state["gui_add_to_menu_bar"]       = add_to_menu_bar;
	}
} // namespace lua::gui

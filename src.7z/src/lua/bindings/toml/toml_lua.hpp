#pragma once

namespace lua::toml_lua
{
	void bind(sol::table& state);
}

#ifndef OPTIONS_H
#define OPTIONS_H

struct Options
{
	bool formattedIntsAsUserData = false;
	bool temporalTypesAsUserData = true;
};
#endif /* OPTIONS_H */

#pragma once
#include "lua/lua_module.hpp"
#include "lua/mod_context.hpp"

namespace lua::gui
{
	void bind(sol::usertype<big::mod_context>& state);
}

#pragma once

namespace lua::paths
{
	void bind(sol::table& state);
}

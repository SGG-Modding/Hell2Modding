#pragma once

#include "lua/mod_context.hpp"

namespace lua::log
{
	void bind(sol::state_view& state, sol::usertype<big::mod_context>& lua_ext);
}

#pragma once

namespace lua::path
{
	void bind(sol::table& state);
}

#include "lua_manager.hpp"

#include "bindings/gui.hpp"
#include "bindings/imgui.hpp"
#include "bindings/log.hpp"
#include "bindings/memory.hpp"
#include "bindings/path.hpp"
#include "bindings/paths.hpp"
#include "bindings/toml/toml_lua.hpp"
#include "file_manager/file_manager.hpp"
#include "string/string.hpp"

#include <thunderstore/v1/manifest.hpp>
#include <unordered_set>

namespace big
{
	static std::optional<module_info> get_module_info(const std::filesystem::path& module_path)
	{
		constexpr auto thunderstore_manifest_json_file_name = "manifest.json";
		std::filesystem::path manifest_path;
		std::filesystem::path current_folder = module_path.parent_path();
		std::filesystem::path root_folder    = g_file_manager.get_base_dir();
		while (true)
		{
			if (current_folder == root_folder)
			{
				break;
			}

			const auto potential_manifest_path = current_folder / thunderstore_manifest_json_file_name;
			if (std::filesystem::exists(potential_manifest_path))
			{
				manifest_path = potential_manifest_path;
				break;
			}

			if (current_folder.has_parent_path())
			{
				current_folder = current_folder.parent_path();
			}
			else
			{
				break;
			}
		}

		if (!std::filesystem::exists(manifest_path))
		{
			LOG(WARNING) << "No manifest path, can't load " << reinterpret_cast<const char*>(module_path.u8string().c_str());
			return {};
		}

		std::ifstream manifest_file(manifest_path);
		nlohmann::json manifest_json = nlohmann::json::parse(manifest_file, nullptr, false, true);

		ts::v1::manifest manifest = manifest_json.get<ts::v1::manifest>();

		manifest.version = semver::version::parse(manifest.version_number);

		for (const auto& dep : manifest.dependencies)
		{
			const auto splitted = big::string::split(dep, '-');
			if (splitted.size() == 3)
			{
				manifest.dependencies_no_version_number.push_back(splitted[0] + '-' + splitted[1]);
			}
			else
			{
				LOG(FATAL) << "Invalid dependency string " << dep << " inside the following manifest: " << manifest_path << ". Example format: AuthorName-ModName-1.0.0";
			}
		}

		const std::string folder_name = (char*)current_folder.filename().u8string().c_str();
		const auto sep_count          = std::ranges::count(folder_name, '-');
		if (sep_count != 1)
		{
			LOGF(FATAL,
			     "Bad folder name ({}) for the following mod: {}. Should be the following format: AuthorName-ModName",
			     folder_name,
			     manifest.name);
		}

		const std::string guid = folder_name;
		return {{
		    .m_path              = module_path,
		    .m_folder_path       = current_folder,
		    .m_guid              = guid,
		    .m_guid_with_version = guid + "-" + manifest.version_number,
		    .m_manifest          = manifest,
		}};
	}

	lua_manager::lua_manager(lua_State* game_lua_state, folder config_folder, folder plugins_data_folder, folder plugins_folder) :
	    m_state(game_lua_state),
	    m_config_folder(config_folder),
	    m_plugins_data_folder(plugins_data_folder),
	    m_plugins_folder(plugins_folder)
	{
		g_lua_manager = this;

		init_lua_state();

		load_all_modules();

		lua::window::deserialize();
	}

	lua_manager::~lua_manager()
	{
		LOG(WARNING) << "killin lua_mgr";

		lua::window::serialize();

		unload_all_modules();

		g_lua_manager = nullptr;
	}

	void lua_manager::init_lua_state()
	{
		init_lua_api();
	}

	void lua_manager::init_lua_api()
	{
		sol::table lua_ext = m_state.create_named_table(lua_ext_namespace);
		sol::table mods    = lua_ext.create_named("mods");
		// Lua API: Function
		// Table: mods
		// Name: on_all_mods_loaded
		// Param: callback: function: callback that will be called once all mods are loaded. The callback function should match signature func()
		// Registers a callback that will be called once all mods are loaded. Will be called instantly if mods are already loaded and that you are just hot-reloading your mod.
		mods["on_all_mods_loaded"] = [](sol::protected_function cb, sol::this_environment env)
		{
			big::lua_module* mdl = big::lua_module::this_from(env);
			if (mdl)
			{
				mdl->m_data.m_on_all_mods_loaded_callbacks.push_back(cb);
			}
		};
	}

	static void imgui_text(const char* fmt, const std::string& str)
	{
		if (str.size())
		{
			ImGui::Text(fmt, str.c_str());
		}
	}

	void lua_manager::draw_menu_bar_callbacks()
	{
		/*std::scoped_lock guard(m_module_lock);

		for (const auto& module : m_modules)
		{
			if (ImGui::BeginMenu(module->guid().c_str()))
			{
				if (ImGui::BeginMenu("Mod Info"))
				{
					const auto& manifest = module->manifest();
					imgui_text("Version: %s", manifest.version_number);
					imgui_text("Website URL: %s", manifest.website_url);
					imgui_text("Description: %s", manifest.description);
					if (manifest.dependencies.size())
					{
						int i = 0;
						for (const auto& dependency : manifest.dependencies)
						{
							imgui_text(std::format("Dependency[{}]: %s", i++).c_str(), dependency);
						}
					}

					ImGui::EndMenu();
				}

				for (const auto& element : module->m_data.m_menu_bar_callbacks)
				{
					element->draw();
				}

				ImGui::EndMenu();
			}
		}*/
	}

	void lua_manager::always_draw_independent_gui()
	{
		std::scoped_lock guard(m_module_lock);

		for (const auto& module : m_modules)
		{
			//for (const auto& element : module->m_data.m_always_draw_independent_gui)
			{
				//element->draw();
			}
		}
	}

	void lua_manager::draw_independent_gui()
	{
		std::scoped_lock guard(m_module_lock);

		for (const auto& module : m_modules)
		{
			//for (const auto& element : module->m_data.m_independent_gui)
			{
				//element->draw();
			}
		}
	}

	void lua_manager::unload_module(const std::string& module_guid)
	{
		std::scoped_lock guard(m_module_lock);

		/*std::erase_if(m_modules,
		              [&](auto& module)
		              {
			              return module_guid == module->guid();
		              });*/
	}

	load_module_result lua_manager::load_module(const module_info& module_info, bool ignore_failed_to_load)
	{
		if (!std::filesystem::exists(module_info.m_path))
		{
			return load_module_result::FILE_MISSING;
		}

		std::scoped_lock guard(m_module_lock);
		for (const auto& module : m_modules)
		{
			//if (module->guid() == module_info.m_guid)
			{
				LOG(WARNING) << "Module with the guid " << module_info.m_guid << " already loaded.";
				return load_module_result::ALREADY_LOADED;
			}
		}

		const auto module_index = m_modules.size();
		m_modules.push_back(std::make_unique<lua_module>(module_info, m_state));

		/*const auto load_result = m_modules[module_index]->load_and_call_plugin(m_state);
		if (load_result == load_module_result::SUCCESS || (load_result == load_module_result::FAILED_TO_LOAD && ignore_failed_to_load))
		{
			if (m_is_all_mods_loaded)
			{
				for (const auto& cb : m_modules[module_index]->m_data.m_on_all_mods_loaded_callbacks)
				{
					cb();
				}
			}
		}
		else
		{
			m_modules.pop_back();
		}*/


		//return load_result;
	}

	bool lua_manager::module_exists(const std::string& module_guid)
	{
		std::scoped_lock guard(m_module_lock);

		for (const auto& module : m_modules)
		{
			//if (module->guid() == module_guid)
			{
				return true;
			}
		}

		return false;
	}

	static bool topological_sort_visit(const std::string& node, std::stack<std::string>& stack, std::vector<std::string>& sorted_list, const std::function<std::vector<std::string>(const std::string&)>& dependency_selector, std::unordered_set<std::string>& visited, std::unordered_set<std::string>& sorted)
	{
		if (visited.contains(node))
		{
			if (!sorted.contains(node))
			{
				return false;
			}
		}
		else
		{
			visited.insert(node);
			stack.push(node);
			for (const auto& dep : dependency_selector(node))
			{
				if (!topological_sort_visit(dep, stack, sorted_list, dependency_selector, visited, sorted))
				{
					return false;
				}
			}

			sorted.insert(node);
			sorted_list.push_back(node);

			stack.pop();
		}

		return true;
	}

	static std::vector<std::string> topological_sort(std::vector<std::string>& nodes, const std::function<std::vector<std::string>(const std::string&)>& dependency_selector)
	{
		std::vector<std::string> sorted_list;

		std::unordered_set<std::string> visited;
		std::unordered_set<std::string> sorted;

		for (const auto& input : nodes)
		{
			std::stack<std::string> current_stack;
			if (!topological_sort_visit(input, current_stack, sorted_list, dependency_selector, visited, sorted))
			{
				LOG(FATAL) << "Cyclic Dependency: " << input;
				while (!current_stack.empty())
				{
					LOG(FATAL) << current_stack.top();
					current_stack.pop();
				}
			}
		}

		return sorted_list;
	}

	void lua_manager::load_all_modules()
	{
		// Map for lexicographical ordering.
		std::map<std::string, module_info> module_guid_to_module_info{};

		// Get all the modules from the folder.
		for (const auto& entry : std::filesystem::recursive_directory_iterator(m_plugins_folder.get_path(), std::filesystem::directory_options::skip_permission_denied))
		{
			if (entry.is_regular_file() && entry.path().filename() == "main.lua")
			{
				const auto module_info = get_module_info(entry.path());
				if (module_info)
				{
					const auto& guid = module_info.value().m_guid;

					if (module_guid_to_module_info.contains(guid))
					{
						if (module_info.value().m_manifest.version > module_guid_to_module_info[guid].m_manifest.version)
						{
							LOG(INFO) << "Found a more recent version of " << guid << " ("
							          << module_info.value().m_manifest.version << " > "
							          << module_guid_to_module_info[guid].m_manifest.version << "): Using that instead.";

							module_guid_to_module_info[guid] = module_info.value();
						}
					}
					else
					{
						module_guid_to_module_info.insert({guid, module_info.value()});
					}
				}
			}
		}

		// Get all the guids to prepare for sorting depending on their dependencies.
		std::vector<std::string> module_guids;
		for (const auto& [guid, info] : module_guid_to_module_info)
		{
			module_guids.push_back(guid);
		}

		// Sort depending on module dependencies.
		const auto sorted_modules = topological_sort(module_guids,
		                                             [&](const std::string& guid)
		                                             {
			                                             if (module_guid_to_module_info.contains(guid))
			                                             {
				                                             return module_guid_to_module_info[guid].m_manifest.dependencies_no_version_number;
			                                             }
			                                             return std::vector<std::string>();
		                                             });

		/*
		for (const auto& guid : sorted_modules)
		{
			LOG(VERBOSE) << guid;
		}
		*/

		std::unordered_set<std::string> missing_modules;
		for (const auto& guid : sorted_modules)
		{
			constexpr auto mod_loader_name = "Hell2Modding-Hell2Modding";

			bool not_missing_dependency = true;
			for (const auto& dependency : module_guid_to_module_info[guid].m_manifest.dependencies_no_version_number)
			{
				// The mod loader is not a lua module,
				// but might be put as a dependency in the mod manifest,
				// don't mark the mod as unloadable because of that.
				if (dependency.contains(mod_loader_name))
				{
					continue;
				}

				if (missing_modules.contains(dependency))
				{
					LOG(WARNING) << "Can't load " << guid << " because it's missing " << dependency;
					not_missing_dependency = false;
				}
			}

			if (not_missing_dependency)
			{
				const auto& module_info = module_guid_to_module_info[guid];
				const auto load_result  = load_module(module_info);
				if (load_result == load_module_result::FILE_MISSING)
				{
					// Don't log the fact that the mod loader failed to load, it's normal (see comment above)
					if (!guid.contains(mod_loader_name))
					{
						LOG(WARNING) << guid
						             << " (file path: " << reinterpret_cast<const char*>(module_info.m_path.u8string().c_str()) << " does not exist in the filesystem. Not loading it.";
					}

					missing_modules.insert(guid);
				}
			}
		}

		std::scoped_lock guard(m_module_lock);
		for (const auto& module : m_modules)
		{
			//for (const auto& cb : module->m_data.m_on_all_mods_loaded_callbacks)
			{
				//cb();
			}
		}

		m_is_all_mods_loaded = true;
	}

	void lua_manager::unload_all_modules()
	{
		std::scoped_lock guard(m_module_lock);

		for (auto& module : m_modules)
		{
			module.reset();
		}

		m_modules.clear();
	}
} // namespace big

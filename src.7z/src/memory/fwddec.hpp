#pragma once

namespace memory
{
	class handle;
	class range;
	class module;
	class pattern;
	class pattern_batch;
	class byte_patch;
} // namespace memory

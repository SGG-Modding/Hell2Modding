#include "version.hpp"

namespace big
{
	const char* version::GIT_SHA1           = "310f05afc0f0e9045cc2b6d006dc1045e00ecac6-dirty";
	const char* version::GIT_BRANCH         = "master";
	const char* version::GIT_DATE           = "Wed Apr 24 18:16:47 2024";
	const char* version::GIT_COMMIT_SUBJECT = "nightly: make thunderstore release too";
};

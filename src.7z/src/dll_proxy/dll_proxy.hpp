#pragma once

namespace big
{
	struct dll_proxy
	{
		static void init();
	};
} // namespace big
